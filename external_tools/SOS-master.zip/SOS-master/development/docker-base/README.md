# Base SoS docker

Base SoS docker image with only anaconda python 3 and SoS installed.

## Basic usage

```
docker run -it mdabioinfo/sos-base /bin/bash
```
